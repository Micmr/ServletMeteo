 

import javax.servlet.http.*;
import java.util.*;

public class MeteoClasse extends HttpServlet
{
    public void doGet(HttpServletRequest request,HttpServletResponse response){
      String[] settimana=new String[7];
      int nr;
      for(int i=0;i<7;i++)
        {nr=(int)(Math.random()*100);
        if(nr<20)
        {
            settimana[i]="Soleggiato";
        }
        else if(nr<40)
        {
          settimana[i]="Piovoso";
        }
         else if(nr<60)
        {
          settimana[i]="Nuvoloso";
        }
         else if(nr<80)
        {
          settimana[i]="Nevoso";
        }
        else
        {
         settimana[i]="Nebbioso";  
        }
        }
      try{response.getOutputStream().println("Lunedi:"+settimana[0]+"  Martedi:"+settimana[1]+"  Mercoledi:"+settimana[2]+"  Giovedi:"+settimana[3]+"  Venerdi:"+settimana[4]+"  Sabato:"+settimana[5]+"  Domenica:"+settimana[6]);}catch(Exception e){}
    }
}